// This file must NOT be checked in to git hub.  Make sure it is listed
// in the .gitignore file for the repository

var ppSecrets = {
    ppUrl: 'https://pricespaid.acquisition.gov/apisolr',
    basicAuthUsername: 'pricespaid',
    basicAuthPassword: 'DemlOgKy5gLLfL3r',
    serviceUsername: 'tester0',
    servicePassword: 'qZfRppRwcrGxi'
}
