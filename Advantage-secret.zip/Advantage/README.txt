Developer's README file for the GSA Advantage Helper Chrome Extension
This file lives at:
